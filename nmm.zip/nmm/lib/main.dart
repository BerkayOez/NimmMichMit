import 'package:flutter/material.dart';

void main() {
  runApp(
    MyApp()
  );
}

class MyApp extends StatelessWidget {
  const MyApp({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Colors.red,
          title: const Text('Nimm Mich Mit'),
          leading: GestureDetector(
            child: Icon(
              Icons.menu,
            ),
          ),
        ),
      body: SafeArea(
        child: Container(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Expanded(
                flex: 4,
              
                child: CircleAvatar(
                  backgroundColor: Colors.red.shade200,
                  radius: 150.0,
                  child: Container(
                    height: double.infinity,
                    child: CircleAvatar(
                      foregroundColor: Colors.black,
                      backgroundColor: Colors.white,
                      radius: 148.0,

                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Container(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: <Widget>[
                               Text(
                                 'VON',
                                  style: TextStyle(
                                    fontSize: 50.0,
                                    fontFamily: 'SourceSansPro',
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            
                            ),
                            
                          ),

                          SizedBox(
                            height: 20.0,
                            width: 170.0,
                            child: Divider(
                              thickness: 2.0,
                              color: Colors.red.shade900,
                            ),
                          ),

                          Container(
                            child: TextField(
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 50.0,
                                fontFamily: 'SourceSansPro',
                                fontWeight: FontWeight.bold,
                              ),
                              decoration: InputDecoration(
                                hoverColor: Colors.black,
                                hintText: "NACH",
                                border: InputBorder.none,
                              ),
                            ),
                          ),

                        ],
                      ),

                    ),
                  ),
                ),

              ),

              SizedBox(
                height: 5.0,
                child: Divider(
                  color: Colors.black,
                ),
              ),
              
               Expanded(
                flex: 5,
                child: Container(
                  height: double.infinity,
                  color: Colors.red,
                  child: ClipOval(
                    clipBehavior: Clip.antiAlias,
                    child: Text('HI'),
                    
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    ),
    );
  }
}